# Trainer Rematch

Talk to any trainer you have already beaten and they challenge you to a rematch, with a YES/NO prompt. Supports Generation 1 (Red/Blue/Yellow) and Generation 2 (Gold/Silver/Crystal).

## How it works

1. Beat a field trainer, then walk up and talk to them again.
2. They greet you with a line written for their class. Answer YES to battle again or NO to keep the normal post-battle dialogue.
3. On Gen 1, regular trainer rematches randomize the opponent's team while preserving the trainer's party size (up to six). Species are selected to spread the team's types, and each Pokémon gets four distinct, PP-bearing damaging moves from the loaded Generation 1 move data. Moves favour STAB, accuracy, power, and team-wide type coverage.
4. Each accepted rematch adds 5 levels to the trainer's original party levels. The count is saved per overworld trainer. Regular trainer Pokémon are capped at level 100.
5. Rematch trainers can use contextual battle items: X Attack, X Defense, X Speed, X Special, X Accuracy, Guard Spec., and Full Restore. Setup items are used at most once per active Pokémon and only when the move set or opponent state makes them useful. Full Restores are reserved for low HP or status. Dire Hit is not used.
6. Rematch money and XP are configurable percentages of the usual amounts in MODS > Trainer Rematch. Pay Day remains disabled on rematches.

If the rematch team averages more than 10 levels above your party, the trainer warns you first and asks again.

Gym leaders, rivals, and other scripted encounters keep their original conversations. A Gym Leader only starts offering a field rematch once they have nothing left to hand over: in Gen 2, that includes receiving the badge and any owed TM. A class which marks a dedicated rematch team (`rematchIndex` in its trainer record) uses that roster as the starting level and party-size template for the randomized Gen 1 rematch.

## Gen 1 Boss Rematches

Red, Blue, and Yellow also get a **BOSS REMATCH** entry in the Start menu. It offers Gym Leader rematches once the corresponding badge is owned. Each Gym Leader's team retains its signature type on at least half of the roster when the game's available species permit it, while the rest of the team and its moves provide broader coverage. Giovanni uses his Viridian Gym party.

- After the main-game Champion Rival victory, the Elite Four and Champion Rival become available. Their teams are randomized with broad type coverage and damaging move sets that favour STAB and distinct move types.
- Each accepted boss rematch adds 5 levels based on that boss's original team. All non-ace Pokémon cap at level 100; only the final Pokémon can rise to level 200.
- Bosses can use all six supported setup items intelligently, with up to ten Full Restores per opposing Pokémon below half HP or when statused.
- Defeating the optional Champion Rival rematch unlocks **Professor Oak**. Oak is the postgame final boss: he receives a randomized six-Pokémon team, the same +5 progression, non-ace cap 100, and final ace cap 300.
- Boss rematch counts and Oak's unlock are saved separately from field-trainer rematches.

These level caps affect only rematch opponents. The player's party, normal story battles, and the existing Gen 2 rematch flow are not modified by the Gen 1 randomizer.

## Install

1. Install the mod into the game's `mods/` folder or import the ZIP through the launcher.
2. Restart the game and enable the mod if it is not already enabled.
3. For field rematches, defeat a regular trainer and speak to them again. For Gen 1 bosses, open **BOSS REMATCH** from the Start menu after unlocking the relevant entries.

## Version 0.8.0 changes

- Regular trainer rematch levels now cap at 100; the +5 accepted-rematch progression remains persistent.
- Teams use type-diverse species selection and moves drawn only from valid, PP-bearing damaging Generation 1 moves. Move sets favour STAB, coverage, power, and accuracy.
- Gym Leader rosters retain their signature type while adding coverage; Elite Four, Rival, and Oak teams use broad type diversity.
- Rematch trainers can use X Attack, X Defense, X Speed, X Special, X Accuracy, and Guard Spec. when appropriate, plus Full Restores. The item AI avoids redundant setup and does not use Dire Hit.
- Fixed the AI action handoff and active Pokémon move-pointer update so the generated moves and chosen items are passed through the engine's expected structures.
- Added headless coverage for level caps, type focus/diversity, move validity, and contextual item decisions.
