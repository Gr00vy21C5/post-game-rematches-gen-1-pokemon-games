-- Trainer Rematch: talk to a trainer you have already beaten to get a
-- rematch.  Rematch battles award a percentage of the usual money and
-- experience (MODS > Trainer Rematch: 0-100% in 10% steps; money
-- defaults to 0%, XP to 100%).  Each trainer class opens with a line in
-- its own voice, matched to the personality that class shows in its
-- regular dialogue.

-- One line per trainer class, written in the class's voice.  The line
-- leads straight into the YES/NO prompt, so every one reads as a
-- challenge.  Rows are the text box's lines (max 18 chars each, max 2 lines per box).
local REMATCH_LINES = {
  -- Gen 1 / Shared classes
  OPP_YOUNGSTER    = "I like shorts!\nRematch with me?",
  OPP_BUG_CATCHER  = "My BUG POKéMON\nwant a rematch!",
  OPP_LASS         = "I've trained since\nwe fought. Again?",
  OPP_SAILOR       = "Ahoy, landlubber!\nOne more battle?",
  OPP_JR_TRAINER_M = "I'll try harder\nnow. Let's battle!",
  OPP_JR_TRAINER_F = "I've practiced a\nlot! Rematch?",
  OPP_POKEMANIAC   = "Caught even more\nPOKéMON! Rematch?",
  OPP_SUPER_NERD   = "I studied your\nmoves. Try again?",
  OPP_HIKER        = "Climbed mountains\nsince then! Fight?",
  OPP_BIKER        = "Back for more?\nLet's ride again!",
  OPP_BURGLAR      = "You beat me once.\nTime to settle it!",
  OPP_ENGINEER     = "Built new machines\nfor this! Battle?",
  OPP_UNUSED_JUGGLER = "New juggling moves\nto show! Rematch?",
  OPP_FISHER       = "Caught more than\nfish! Care to try?",
  OPP_SWIMMER      = "The water is fine!\nLet's go again!",
  OPP_CUE_BALL     = "Not done with you\nyet. Rematch!",
  OPP_GAMBLER      = "Bet my POKéMON can\nwin this time!",
  OPP_BEAUTY       = "I won't lose this\ntime. Rematch?",
  OPP_PSYCHIC_TR   = "I saw your return!\nBattle again?",
  OPP_ROCKER       = "Encore is over!\nReady for round 2?",
  OPP_JUGGLER      = "New juggling moves\nto show! Rematch?",
  OPP_TAMER        = "My beasts hunger\nfor a rematch!",
  OPP_BIRD_KEEPER  = "My flock wants to\nbattle you again!",
  OPP_BLACKBELT    = "Trained hard since\nlast time! Fight?",
  OPP_RIVAL1       = "You again? I won't\nlose this time!",
  OPP_RIVAL2       = "You again? I won't\nlose this time!",
  OPP_RIVAL3       = "You again? I won't\nlose this time!",
  OPP_PROF_OAK     = "Care to battle me\nagain, my friend?",
  OPP_CHIEF        = "I won't lose\ntwice! Rematch!",
  OPP_SCIENTIST    = "Research says I'll\nwin now! Rematch?",
  OPP_GIOVANNI     = "Nerve to return?\nWe shall see!",
  OPP_ROCKET       = "Team Rocket always\nreturns! Battle?",
  OPP_COOLTRAINER_M = "I've grown much\nstronger! Rematch?",
  OPP_COOLTRAINER_F = "You're strong, but\nI've trained! Go?",
  OPP_BRUNO        = "Hoo hah! Muscles\ngrown! Rematch!",
  OPP_BROCK        = "My rock-hard team\nawaits you again!",
  OPP_MISTY        = "My WATER POKéMON\nare ready! Battle?",
  OPP_LT_SURGE     = "Shock me again if\nyou can, kid!",
  OPP_ERIKA        = "Lovely to see you.\nShall we battle?",
  OPP_KOGA         = "Prove your growth\nonce more! Fight!",
  OPP_BLAINE       = "Fire burns hotter\nthe second time!",
  OPP_SABRINA      = "I foresaw this.\nI have been ready.",
  OPP_GENTLEMAN    = "Care for another\ncivilized bout?",
  OPP_LORELEI      = "The cold winds\ncall us! Battle?",
  OPP_CHANNELER    = "Spirits wish for\nanother battle!",
  OPP_AGATHA       = "Heh heh! Back for\nmore, are you?",
  OPP_LANCE        = "My dragons hunger\nfor battle! Ready?",

  -- Gen 2 Leaders, Elite Four & Champions
  OPP_FALKNER      = "I've been training\nsince our battle.\fShall we battle in\nthe sky once more?",
  OPP_BUGSY        = "BUG research has\ndeepened! Rematch?",
  OPP_WHITNEY      = "I won't cry now!\nLet's fight again!",
  OPP_MORTY        = "Ghosts trained in\nsecret! Rematch?",
  OPP_CHUCK        = "HRAAGH! Waterfall\ntraining! Rematch?",
  OPP_JASMINE      = "My steel defense\nhas grown! Battle?",
  OPP_PRYCE        = "Winter tempered my\nresolve! Rematch?",
  OPP_CLAIR        = "I won't lose now!\nFace my dragons!",
  OPP_WILL         = "I foresaw our next\nclash! Prepared?",
  OPP_KAREN        = "Battle with your\nfavorites again!",
  OPP_JANINE       = "Ninja skills won't\nfail me! Prepare!",
  OPP_RED          = "... ... ...\n... ... Rematch?",
  OPP_BLUE         = "Smell ya later?\nNo way! Let's go!",
  OPP_CAL          = "Test our skills\nonce more! Ready?",

  -- Gen 2 Johto/Kanto Trainer Classes
  OPP_SCHOOLBOY    = "Studied all battle\ntheory! Test me!",
  OPP_SKIER        = "Snow is fresh and\nso is my team! Go!",
  OPP_TEACHER      = "Time for a pop\nquiz in battling!",
  OPP_FIREBREATHER = "My fire burns even\nhotter! Feel heat!",
  OPP_SAGE         = "Harmony of spirits\ntested once more.",
  OPP_MEDIUM       = "Spirits gather for\nour battle. Begin?",
  OPP_BOARDER      = "New moves on the\nsnow! Rematch?",
  OPP_POKEFANM     = "Darling POKéMON\nready to show off!",
  OPP_POKEFANF     = "My sweet POKéMON\ncare to battle?",
  OPP_KIMONO_GIRL  = "Dance with our\nPOKéMON once more?",
  OPP_TWINS        = "Twice as tough as\nbefore! Rematch?",
  OPP_OFFICER      = "Halt! Care for a\nfriendly spar?",
  OPP_EXECUTIVEM   = "Team Rocket will\nnot lose! Rematch!",
  OPP_EXECUTIVEF   = "Pay for meddling\nwith us! Rematch!",
  OPP_MYSTICALMAN  = "Passion for legend\nnever wanes! Go!",
}

local DEFAULT_LINE = "Looking for a\nrematch with me?"

-- One line per trainer class for when the player says NO.  Cocky and
-- rough classes mock the player; wise and polite ones are understanding.
local REMATCH_DECLINES = {
  -- Gen 1 / Shared classes
  OPP_YOUNGSTER    = "Ha! I knew it!\nToo scared for me!",
  OPP_BUG_CATCHER  = "Scared of a few\nlittle bugs? Haha!",
  OPP_LASS         = "Oh, I see. Too\nfrightened of me!",
  OPP_SAILOR       = "Avast! Scared of\nthe sea, are ya?",
  OPP_JR_TRAINER_M = "Coward! Scared of\na real battle!",
  OPP_JR_TRAINER_F = "You're scared, I\nknew it! Teehee!",
  OPP_POKEMANIAC   = "Ha! My collection\nscared you off!",
  OPP_SUPER_NERD   = "Fear is just poor\ncalculations.",
  OPP_HIKER        = "Hmph! Scared of a\nlittle climb, eh?",
  OPP_BIKER        = "Chicken! My wheels\nare too fast!",
  OPP_BURGLAR      = "Smart move. You'd\nlose to me anyway.",
  OPP_ENGINEER     = "Fear of machine\nfailure? Fitting!",
  OPP_UNUSED_JUGGLER = "Afraid I'll juggle\nyou dizzy? Heh.",
  OPP_FISHER       = "Got cold feet,\ndid ya? Ha!",
  OPP_SWIMMER      = "Scared to dip your\ntoes in, huh?",
  OPP_CUE_BALL     = "Hah! Scared of my\ntough moves!",
  OPP_GAMBLER      = "Chicken out? I'd\nhave bet on it!",
  OPP_BEAUTY       = "Afraid my POKéMON\nwill outshine you?",
  OPP_PSYCHIC_TR   = "I can see fear.\nIt's quite loud.",
  OPP_ROCKER       = "Too loud for you?\nHa! What a wimp!",
  OPP_JUGGLER      = "Afraid I'll juggle\nyou dizzy? Heh.",
  OPP_TAMER        = "Wise. My beasts\nwould crush you.",
  OPP_BIRD_KEEPER  = "Scared of a little\nflight? Ha!",
  OPP_BLACKBELT    = "Wise choice. My\nfists are strong.",
  OPP_RIVAL1       = "Ha! What a wimp.\nSee ya later!",
  OPP_RIVAL2       = "Ha! What a wimp.\nSee ya later!",
  OPP_RIVAL3       = "Ha! What a wimp.\nSee ya later!",
  OPP_PROF_OAK     = "Very well. Return\nwhen you're ready.",
  OPP_CHIEF        = "Chicken! I thought\nyou had nerve!",
  OPP_SCIENTIST    = "Fear is a variable\nI accounted for.",
  OPP_GIOVANNI     = "Coward. I expected\nbetter of you.",
  OPP_ROCKET       = "Scared of Team\nRocket's power?",
  OPP_COOLTRAINER_M = "Too cool for a\nrematch? Ha!",
  OPP_COOLTRAINER_F = "Chicken! I thought\nyou were strong.",
  OPP_BRUNO        = "Hoo hah! Fear is\nweakness! Train!",
  OPP_BROCK        = "Not ready yet?\nCome back later.",
  OPP_MISTY        = "Scared of getting\nsoaked? Heh!",
  OPP_LT_SURGE     = "Ha! Scared of a\nlittle shock, kid?",
  OPP_ERIKA        = "How shy. I will be\nhere when ready.",
  OPP_KOGA         = "Fear is poison.\nTrain your mind.",
  OPP_BLAINE       = "Ha! The heat is\ntoo much for you!",
  OPP_SABRINA      = "I foresaw this.\nFear is obvious.",
  OPP_GENTLEMAN    = "A true gentleman\nnever presses.",
  OPP_LORELEI      = "Cold feet in cold\nwinds? Fitting.",
  OPP_CHANNELER    = "Spirits can wait.\nFear is natural.",
  OPP_AGATHA       = "Heh heh! Scared of\nan old woman?",
  OPP_LANCE        = "I respect care.\nTrain and return.",

  -- Gen 2 Leaders, Elite Four & Champions
  OPP_FALKNER      = "I understand. The\nskies can wait.",
  OPP_BUGSY        = "Aw, don't bug out\non me now!",
  OPP_WHITNEY      = "Waaah! Why're you\nbeing so mean?",
  OPP_MORTY        = "Unseen paths are\nnot for everyone.",
  OPP_CHUCK        = "Wahaha! Need to\nbulk up first?",
  OPP_JASMINE      = "I understand...\nTake care, then.",
  OPP_PRYCE        = "A frozen heart\ncannot battle.",
  OPP_CLAIR        = "Hmph! Don't waste\nmy time, then!",
  OPP_WILL         = "You cannot escape\nyour destiny.",
  OPP_KAREN        = "Hmph. How very\ndisappointing.",
  OPP_JANINE       = "Hahaha! Fooled by\nmy illusions?",
  OPP_RED          = "... ...\n... ...",
  OPP_BLUE         = "Haha! Still scared\nof the CHAMPION?",
  OPP_CAL          = "Come back when you\nare ready.",

  -- Gen 2 Johto/Kanto Trainer Classes
  OPP_SCHOOLBOY    = "Aww, back to my\nstudies then...",
  OPP_SKIER        = "Brrr! Got cold\nfeet already?",
  OPP_TEACHER      = "You get an F for\neffort today!",
  OPP_FIREBREATHER = "Too hot to handle,\nhuh?",
  OPP_SAGE         = "Patience and peace\nbe with you.",
  OPP_MEDIUM       = "Spirits depart in\nsilence...",
  OPP_BOARDER      = "Wiped out before\nwe started?",
  OPP_POKEFANM     = "Oh, you're missing\nout on cuteness!",
  OPP_POKEFANF     = "My POKéMON are too\nsweet for you!",
  OPP_KIMONO_GIRL  = "A gentle bow to\nyour prudence.",
  OPP_TWINS        = "Aww! You're no fun\nat all!",
  OPP_OFFICER      = "Move along then,\ncitizen!",
  OPP_EXECUTIVEM   = "Coward! You know\nRocket's power!",
  OPP_EXECUTIVEF   = "Smart of you to\nrun away.",
  OPP_MYSTICALMAN  = "The wind guides\nyou elsewhere...",
}

local DEFAULT_DECLINE = "Ha! Scared of a\nrematch, are you?"

-- One line per trainer class for the "your team is far stronger" warning,
-- spoken when the rematch team averages more than 10 levels above the
-- player's party.  Same voice as the challenge lines: the class owns the
-- warning.  Rows are the text box's lines (max 18 chars each, max 2 lines per box).
local REMATCH_WARNINGS = {
  OPP_BROCK      = "My team is far\nstronger. Sure?",
  OPP_MISTY      = "My team is far\nbeyond yours! Go?",
  OPP_LT_SURGE   = "Warning: my team\nis high level! Go?",
  OPP_ERIKA      = "My flowers bloomed\npast you. Sure?",
  OPP_KOGA       = "My deadly poison\nis beyond you! Go?",
  OPP_BLAINE     = "The heat burns far\nbeyond you! Ready?",
  OPP_SABRINA    = "I see your team is\noutmatched. Sure?",
  OPP_LORELEI    = "My cold winds are\nfar stronger! Go?",
  OPP_BRUNO      = "Hoo hah! My power\nis far beyond you!",
  OPP_AGATHA     = "Heh! My ghosts are\nfar above you! Go?",
  OPP_LANCE      = "My dragons tower\nfar above you! Go?",
  OPP_RIVAL3     = "My team is far\nstronger! Sure?",

  -- Gen 2 Leaders & Bosses
  OPP_FALKNER    = "My birds soar far\nabove you. Sure?",
  OPP_BUGSY      = "My bugs swarm far\nbeyond you. Ready?",
  OPP_WHITNEY    = "Cute POKéMON are\nsuper tough! Sure?",
  OPP_MORTY      = "My ghost POKéMON\nlurk beyond! Sure?",
  OPP_CHUCK      = "HRAAGH! Crush you\nwith power! Sure?",
  OPP_JASMINE    = "My steel defense\nis far beyond you!",
  OPP_PRYCE      = "Biting cold will\nfreeze you. Ready?",
  OPP_CLAIR      = "Dragon wrath is\nbeyond you! Ready?",
  OPP_WILL       = "I saw your team is\noutmatched. Sure?",
  OPP_KAREN      = "Dark team is far\nstronger now. Go?",
  OPP_JANINE     = "Toxic tricks are\nbeyond you! Ready?",
  OPP_RED        = "... ... ...!\n(He is powerful!)",
  OPP_BLUE       = "My genius team is\nway out of league!",
  OPP_CAL        = "Training team is\nfar above! Sure?",
  OPP_EXECUTIVEM = "Executive power\nis far beyond you!",
  OPP_EXECUTIVEF = "I'll crush you\nwithout mercy! Go?",
}

local DEFAULT_WARN = "My team is far\nstronger! Sure?"

-- Normalize trainer class names across Gen 1 (OPP_ prefix), Gen 2 (bare names),
-- and variant naming spellings.
local ALIAS_MAP = {
  OPP_COOLTRAINERM = "OPP_COOLTRAINER_M",
  COOLTRAINERM     = "OPP_COOLTRAINER_M",
  COOLTRAINER_M    = "OPP_COOLTRAINER_M",
  OPP_COOLTRAINERF = "OPP_COOLTRAINER_F",
  COOLTRAINERF     = "OPP_COOLTRAINER_F",
  COOLTRAINER_F    = "OPP_COOLTRAINER_F",
  OPP_BLACKBELT_T  = "OPP_BLACKBELT",
  BLACKBELT_T      = "OPP_BLACKBELT",
  BLACKBELT        = "OPP_BLACKBELT",
  OPP_PSYCHIC_T    = "OPP_PSYCHIC_TR",
  PSYCHIC_T        = "OPP_PSYCHIC_TR",
  PSYCHIC_TR       = "OPP_PSYCHIC_TR",
  OPP_SWIMMERM     = "OPP_SWIMMER",
  SWIMMERM         = "OPP_SWIMMER",
  OPP_SWIMMERF     = "OPP_SWIMMER",
  SWIMMERF         = "OPP_SWIMMER",
  SWIMMER          = "OPP_SWIMMER",
  OPP_CAMPER       = "OPP_JR_TRAINER_M",
  CAMPER           = "OPP_JR_TRAINER_M",
  JR_TRAINER_M     = "OPP_JR_TRAINER_M",
  OPP_PICNICKER    = "OPP_JR_TRAINER_F",
  PICNICKER        = "OPP_JR_TRAINER_F",
  JR_TRAINER_F     = "OPP_JR_TRAINER_F",
  OPP_GUITARIST    = "OPP_ROCKER",
  GUITARIST        = "OPP_ROCKER",
  ROCKER           = "OPP_ROCKER",
  OPP_GRUNTM       = "OPP_ROCKET",
  GRUNTM           = "OPP_ROCKET",
  OPP_GRUNTF       = "OPP_ROCKET",
  GRUNTF           = "OPP_ROCKET",
  ROCKET           = "OPP_ROCKET",
  OPP_CHAMPION     = "OPP_LANCE",
  CHAMPION         = "OPP_LANCE",
  LANCE            = "OPP_LANCE",
  OPP_POKEMON_PROF = "OPP_PROF_OAK",
  POKEMON_PROF     = "OPP_PROF_OAK",
  PROF_OAK         = "OPP_PROF_OAK",
}

local function normalizeClassId(classId)
  if not classId then return nil end
  if type(classId) ~= "string" then classId = tostring(classId) end
  if ALIAS_MAP[classId] then return ALIAS_MAP[classId] end
  if REMATCH_LINES[classId] then return classId end
  local opp = "OPP_" .. classId
  if REMATCH_LINES[opp] then return opp end
  if classId:sub(1, 4) == "OPP_" then
    local stripped = classId:sub(5)
    if REMATCH_LINES[stripped] then return stripped end
    if ALIAS_MAP[stripped] then return ALIAS_MAP[stripped] end
  end
  return classId
end

local function resolveWarning(classId)
  local key = normalizeClassId(classId)
  return (key and REMATCH_WARNINGS[key]) or REMATCH_WARNINGS[classId] or DEFAULT_WARN
end

-- How many levels the trainer's team averages above the player's party;
-- nil when either side is empty, so callers can skip the warning.
local function levelGap(playerParty, team)
  if not team or #team == 0 then return nil end
  local playerLevels, playerCount = 0, 0
  if playerParty then
    for _, mon in ipairs(playerParty) do
      if mon and mon.level then
        playerLevels = playerLevels + mon.level
        playerCount = playerCount + 1
      end
    end
  end
  if playerCount == 0 then return nil end
  local teamLevels = 0
  for _, slot in ipairs(team) do
    teamLevels = teamLevels + (slot.level or 0)
  end
  return (teamLevels / #team) - (playerLevels / playerCount)
end

-- Gen 1 rematch difficulty. These changes apply only while a defeated
-- trainer is being rebuilt for a rematch. Source trainer records, normal
-- story battles, wild encounters, and the player's party stay untouched.
local REMATCH_LEVEL_STEP = 5
local REMATCH_LEVEL_CAP = 100
-- Six one-time setup items plus the original five Full Restore uses.
local REMATCH_AI_USES = 11
local REMATCH_RESTORE_USES = 5
local REMATCH_COUNT_STORE = "gen1TrainerRematchCounts"

local GEN1_TYPES = {
  NORMAL = true, FIGHTING = true, FLYING = true, POISON = true,
  GROUND = true, ROCK = true, BUG = true, GHOST = true,
  FIRE = true, WATER = true, GRASS = true, ELECTRIC = true,
  PSYCHIC = true, ICE = true, DRAGON = true,
}
local PHYSICAL_TYPES = {
  NORMAL = true, FIGHTING = true, FLYING = true, POISON = true,
  GROUND = true, ROCK = true, BUG = true, GHOST = true,
}
local SPECIAL_TYPES = {
  FIRE = true, WATER = true, GRASS = true, ELECTRIC = true,
  PSYCHIC = true, ICE = true, DRAGON = true,
}
-- The non-signature slots in a Gym Leader rematch should be able to answer
-- the signature type's obvious weaknesses. These are the Gen 1 attack types
-- that hit the focused type super-effectively (not a full defensive matrix).
local FOCUS_COUNTER_TYPES = {
  ROCK = { WATER = true, GRASS = true, FIGHTING = true, GROUND = true },
  WATER = { ELECTRIC = true, GRASS = true },
  ELECTRIC = { GROUND = true },
  GRASS = { FIRE = true, ICE = true, FLYING = true, BUG = true, POISON = true },
  POISON = { GROUND = true, PSYCHIC = true },
  PSYCHIC = { BUG = true, GHOST = true },
  FIRE = { WATER = true, GROUND = true, ROCK = true },
  GROUND = { WATER = true, GRASS = true, ICE = true },
  ICE = { FIRE = true, FIGHTING = true, ROCK = true },
  FIGHTING = { FLYING = true, PSYCHIC = true },
  GHOST = { GHOST = true },
  DRAGON = { ICE = true, DRAGON = true },
}
local STAT_DROP_EFFECTS = {
  ATTACK_DOWN1_EFFECT = true, DEFENSE_DOWN1_EFFECT = true,
  SPEED_DOWN1_EFFECT = true, SPECIAL_DOWN1_EFFECT = true,
  ACCURACY_DOWN1_EFFECT = true, EVASION_DOWN1_EFFECT = true,
  ATTACK_DOWN2_EFFECT = true, DEFENSE_DOWN2_EFFECT = true,
  SPEED_DOWN2_EFFECT = true, SPECIAL_DOWN2_EFFECT = true,
  ACCURACY_DOWN2_EFFECT = true, EVASION_DOWN2_EFFECT = true,
}

local function randomIndex(count, rng)
  if count <= 1 then return 1 end
  local value
  if rng then
    value = rng(1, count)
  elseif love and love.math and love.math.random then
    value = love.math.random(1, count)
  else
    value = math.random(1, count)
  end
  value = math.floor(tonumber(value) or 1)
  return math.max(1, math.min(count, value))
end

local function randomUnit(rng)
  return (randomIndex(1000, rng) - 1) / 1000
end

local function copyArray(source)
  local out = {}
  for i, value in ipairs(source or {}) do out[i] = value end
  return out
end

local function speciesTypes(def)
  local raw = def and (def.types or def.typeList)
  if type(raw) ~= "table" then
    raw = { def and (def.type1 or def.primaryType), def and (def.type2 or def.secondaryType) }
  end
  local result, seen = {}, {}
  -- Read both array slots explicitly so a missing primary type cannot hide a
  -- valid secondary type in fallback-shaped records.
  for index = 1, 2 do
    local value = raw[index]
    if type(value) == "table" then value = value.id or value.type end
    local id = type(value) == "string" and value:upper() or nil
    if id and GEN1_TYPES[id] and not seen[id] then
      seen[id] = true
      result[#result + 1] = id
    end
  end
  return result
end

local function collectRandomizableSpecies(data)
  local out = {}
  for id, def in pairs((data and data.pokemon) or {}) do
    local stats = type(def) == "table" and def.baseStats or nil
    if type(id) == "string" and type(stats) == "table"
        and type(stats.hp) == "number" and type(stats.attack) == "number"
        and type(stats.defense) == "number" and type(stats.speed) == "number"
        and type(stats.special) == "number" then
      out[#out + 1] = id
    end
  end
  table.sort(out)
  return out
end

-- Gen 1's data table is the authority for move availability. Restrict the
-- generated pools to real, PP-bearing, typed damaging moves: this avoids
-- four-slot teams made entirely of setup/status moves that cannot deal damage.
local function collectRandomizableMoves(data)
  local out = {}
  for id, def in pairs((data and data.moves) or {}) do
    local moveType = type(def) == "table" and type(def.type) == "string"
        and def.type:upper() or nil
    if type(id) == "string" and id ~= "STRUGGLE"
        and type(def) == "table" and (tonumber(def.pp) or 0) > 0
        and (tonumber(def.power) or 0) > 0 and GEN1_TYPES[moveType] then
      out[#out + 1] = id
    end
  end
  table.sort(out)
  return out
end

local function pickUnique(pool, amount, rng)
  local available = copyArray(pool)
  local result = {}
  while #result < amount and #available > 0 do
    local index = randomIndex(#available, rng)
    result[#result + 1] = table.remove(available, index)
  end
  return result
end

-- Greedy randomized team selection: maximize new type representation,
-- discourage duplicate typing, and preserve a leader's signature type on at
-- least half of its roster when enough species exist for that theme.
local function pickBalancedSpecies(data, speciesPool, count, rng, focusType)
  local remaining, selected, teamTypeCounts = copyArray(speciesPool), {}, {}
  focusType = type(focusType) == "string" and focusType:upper() or nil
  if not GEN1_TYPES[focusType] then focusType = nil end
  local focusTarget, focusCount = math.ceil(count / 2), 0
  local counterTarget, counterCount = math.max(1, math.ceil(count / 3)), 0
  local focusCounters = focusType and FOCUS_COUNTER_TYPES[focusType] or nil

  while #selected < count and #remaining > 0 do
    local scored = {}
    local best = -math.huge
    for index, id in ipairs(remaining) do
      local types = speciesTypes(data.pokemon[id])
      local newTypes, repeatedTypes, focused, countersFocus = 0, 0, false, false
      for _, typeId in ipairs(types) do
        if teamTypeCounts[typeId] then repeatedTypes = repeatedTypes + 1
        else newTypes = newTypes + 1 end
        if typeId == focusType then focused = true end
        if focusCounters and focusCounters[typeId] then countersFocus = true end
      end
      local score = newTypes * 3 - repeatedTypes * 1.5 + randomUnit(rng)
      if focused then
        score = score + (focusCount < focusTarget and 8 or -1)
      elseif focusType and focusCount < focusTarget then
        score = score - 1
      end
      if not focused and countersFocus and counterCount < counterTarget then
        score = score + 6
      end
      if score > best then
        best, scored = score, { index }
      elseif score == best then
        scored[#scored + 1] = index
      end
    end
    local pickAt = scored[randomIndex(#scored, rng)] or 1
    local species = table.remove(remaining, pickAt)
    selected[#selected + 1] = species
    local selectedCountersFocus = false
    for _, typeId in ipairs(speciesTypes(data.pokemon[species])) do
      teamTypeCounts[typeId] = (teamTypeCounts[typeId] or 0) + 1
      if typeId == focusType then focusCount = focusCount + 1 end
      if focusCounters and focusCounters[typeId] then selectedCountersFocus = true end
    end
    if selectedCountersFocus then counterCount = counterCount + 1 end
  end
  return selected
end

local function moveCategory(moveDef)
  if type(moveDef.category) == "string" then
    local category = moveDef.category:lower()
    if category == "physical" or category == "special" then return category end
  end
  local moveType = type(moveDef.type) == "string" and moveDef.type:upper() or nil
  if PHYSICAL_TYPES[moveType] then return "physical" end
  if SPECIAL_TYPES[moveType] then return "special" end
  return nil
end

-- Build a useful four-move set: establish STAB first, then favour distinct
-- move types, solid power/accuracy and team-wide coverage. Every move ID is
-- taken from this generation's loaded move database.
local function buildBalancedMoves(data, species, coveredMoveTypes, rng, focusType)
  local pool = collectRandomizableMoves(data)
  local speciesDef = data.pokemon[species]
  local ownTypes = speciesTypes(speciesDef)
  local stats = speciesDef.baseStats or {}
  local preferredCategory = (tonumber(stats.attack) or 0) >= (tonumber(stats.special) or 0)
      and "physical" or "special"
  local focusCounters = FOCUS_COUNTER_TYPES[focusType]
  local ownTypeSet, chosen, chosenTypes = {}, {}, {}
  for _, typeId in ipairs(ownTypes) do ownTypeSet[typeId] = true end

  while #chosen < math.min(4, #pool) and #pool > 0 do
    local best, scored = -math.huge, {}
    for index, moveId in ipairs(pool) do
      local def = data.moves[moveId]
      local moveType = def.type:upper()
      local power = tonumber(def.power) or 0
      local accuracy = tonumber(def.accuracy) or 100
      local score = math.min(power, 150) / 100
      if ownTypeSet[moveType] then score = score + (#chosen == 0 and 7 or 2.5) end
      if not chosenTypes[moveType] then score = score + 2.25 end
      if not coveredMoveTypes[moveType] then score = score + 1 end
      if focusCounters and focusCounters[moveType] then score = score + 2 end
      if moveCategory(def) == preferredCategory then score = score + 0.5 end
      if accuracy > 0 and accuracy < 70 then score = score - 1.5 end
      if (tonumber(def.pp) or 0) <= 5 then score = score - 0.35 end
      score = score + randomUnit(rng)
      if score > best then
        best, scored = score, { index }
      elseif score == best then
        scored[#scored + 1] = index
      end
    end
    local pickAt = scored[randomIndex(#scored, rng)] or 1
    local moveId = table.remove(pool, pickAt)
    chosen[#chosen + 1] = moveId
    local moveType = data.moves[moveId].type:upper()
    chosenTypes[moveType] = true
    coveredMoveTypes[moveType] = true
  end
  return chosen
end

local function safeRematchSteps(rematchCount)
  local value = math.floor(tonumber(rematchCount) or 1)
  if value < 1 then return 1 end
  return math.min(value, 1000000)
end

local function buildRematchParty(data, sourceParty, rematchCount, nonAceCap, aceCap, rng, teamOptions)
  if type(sourceParty) ~= "table" or #sourceParty == 0 then return nil end
  local speciesPool = collectRandomizableSpecies(data)
  local movePool = collectRandomizableMoves(data)
  if #speciesPool == 0 or #movePool == 0 then return nil end

  local count = math.min(#sourceParty, 6)
  local picks = pickBalancedSpecies(data, speciesPool, count, rng,
    teamOptions and teamOptions.focusType)
  if #picks < count then return nil end

  local steps = safeRematchSteps(rematchCount)
  local coveredMoveTypes, out = {}, {}
  for i = 1, count do
    local originalLevel = tonumber(sourceParty[i] and sourceParty[i].level)
    if not originalLevel or originalLevel < 1 then originalLevel = 5 end
    originalLevel = math.min(300, math.floor(originalLevel))
    local cap = i == count and aceCap or nonAceCap
    local level = math.min(cap, originalLevel + REMATCH_LEVEL_STEP * steps)
    local moves = buildBalancedMoves(data, picks[i], coveredMoveTypes, rng,
      teamOptions and teamOptions.focusType)
    out[i] = { species = picks[i], level = level, moves = moves }
  end
  return out
end

-- Regular trainers are deliberately capped at level 100. The same +5
-- progression remains persistent because callers save the per-NPC count.
local function buildRandomRematchParty(data, sourceParty, rematchCount, rng, teamOptions)
  return buildRematchParty(data, sourceParty, rematchCount,
    REMATCH_LEVEL_CAP, REMATCH_LEVEL_CAP, rng, teamOptions)
end

-- Boss rematches cap every non-ace at 100. The final slot may climb to 200,
-- while Oak is the sole caller allowed to request the 300 ace ceiling.
local BOSS_REMATCH_STEP = 5
local BOSS_NON_ACE_CAP = 100
local BOSS_ACE_CAP = 200
local OAK_ACE_CAP = 300
-- Six setup items plus the original ten Full Restore uses.
local BOSS_REMATCH_AI_USES = 16
local BOSS_RESTORE_USES = 10
local BOSS_COUNT_STORE = "gen1BossRematchCounts"
local OAK_UNLOCK_STORE = "gen1ProfessorOakUnlocked"

local function buildBossRematchParty(data, sourceParty, rematchCount, aceCap, rng, teamOptions)
  local cap = math.floor(tonumber(aceCap) or BOSS_ACE_CAP)
  if cap >= OAK_ACE_CAP then cap = OAK_ACE_CAP
  else cap = BOSS_ACE_CAP end
  return buildRematchParty(data, sourceParty, rematchCount,
    BOSS_NON_ACE_CAP, cap, rng, teamOptions)
end

local function moveListFor(battle, battler)
  local list = battler and (battler.curMoves or (battler.mon and battler.mon.moves)) or {}
  local out = {}
  for _, slot in ipairs(list or {}) do
    local id = type(slot) == "table" and slot.id or slot
    local def = id and battle.data and battle.data.moves and battle.data.moves[id]
    if def then out[#out + 1] = { id = id, def = def } end
  end
  return out
end

local function hasMoveCategory(battle, battler, category)
  for _, row in ipairs(moveListFor(battle, battler)) do
    if (tonumber(row.def.power) or 0) > 0 and moveCategory(row.def) == category then
      return true
    end
  end
  return false
end

local function hasInaccurateMove(battle, battler)
  for _, row in ipairs(moveListFor(battle, battler)) do
    local accuracy = tonumber(row.def.accuracy)
    if (tonumber(row.def.power) or 0) > 0 and accuracy and accuracy > 0 and accuracy < 100 then
      return true
    end
  end
  return false
end

local function playerCanLowerStats(battle)
  for _, row in ipairs(moveListFor(battle, battle.player)) do
    if STAT_DROP_EFFECTS[row.def.effect] then return true end
  end
  return false
end

local function rematchStatCanRise(battle, enemy, stat)
  local stage = tonumber(enemy.stages and enemy.stages[stat]) or 0
  if stage >= 6 then return false end
  local ok, Damage = pcall(require, "src.battle.Damage")
  if ok and Damage and type(Damage.statAtCap) == "function" then
    local success, atCap = pcall(Damage.statAtCap, battle, enemy, stat)
    if success and atCap then return false end
  end
  return true
end

-- Trainer AI items are selected from battle state, not a random item roll.
-- Each setup item is used at most once per active Pokémon and only when its
-- effect can help; Full Restores retain the v0.7.0 per-Pokémon use allowance.
local function chooseRematchTrainerItem(battle, restoreLimit)
  if not battle or not battle.rematch or not battle.enemy or not battle.data then return nil end
  if (tonumber(battle.aiUses) or 0) <= 0 then return nil end
  local enemy = battle.enemy
  local mon = enemy.mon or {}
  local stats = mon.stats or {}
  local maxHp = tonumber(stats.hp) or 0
  local hp = tonumber(mon.hp) or 0
  local enemyIndex = tonumber(battle.enemyIndex) or 1
  local restoreUses = battle.rematchRestoreUses or {}
  local setupUses = battle.rematchSetupUses or {}
  battle.rematchRestoreUses, battle.rematchSetupUses = restoreUses, setupUses
  restoreUses[enemyIndex] = restoreUses[enemyIndex] or 0
  setupUses[enemyIndex] = setupUses[enemyIndex] or {}

  local function available(item)
    return battle.data.items and battle.data.items[item] ~= nil
  end
  local function use(item)
    setupUses[enemyIndex][item] = true
    return item
  end

  local hpLow = maxHp > 0 and hp <= math.floor(maxHp / 2)
  if available("FULL_RESTORE") and (hpLow or mon.status)
      and restoreUses[enemyIndex] < (tonumber(restoreLimit) or REMATCH_RESTORE_USES) then
    restoreUses[enemyIndex] = restoreUses[enemyIndex] + 1
    return "FULL_RESTORE"
  end

  local enemyHasPhysical = hasMoveCategory(battle, enemy, "physical")
  local enemyHasSpecial = hasMoveCategory(battle, enemy, "special")
  local playerHasPhysical = hasMoveCategory(battle, battle.player, "physical")
  local slowerThanPlayer = (tonumber(enemy.curStats and enemy.curStats.speed) or 0)
      < (tonumber(battle.player and battle.player.curStats and battle.player.curStats.speed) or 0)

  -- Accuracy first prevents otherwise reliable high-power moves from missing.
  if available("X_ACCURACY") and not enemy.xAccuracy
      and not setupUses[enemyIndex].X_ACCURACY and hasInaccurateMove(battle, enemy) then
    return use("X_ACCURACY")
  end
  if available("X_ATTACK") and not setupUses[enemyIndex].X_ATTACK
      and enemyHasPhysical and rematchStatCanRise(battle, enemy, "attack") then
    return use("X_ATTACK")
  end
  if available("X_SPECIAL") and not setupUses[enemyIndex].X_SPECIAL
      and enemyHasSpecial and rematchStatCanRise(battle, enemy, "special") then
    return use("X_SPECIAL")
  end
  if available("X_DEFEND") and not setupUses[enemyIndex].X_DEFEND
      and playerHasPhysical and rematchStatCanRise(battle, enemy, "defense") then
    return use("X_DEFEND")
  end
  if available("X_SPEED") and not setupUses[enemyIndex].X_SPEED
      and slowerThanPlayer and rematchStatCanRise(battle, enemy, "speed") then
    return use("X_SPEED")
  end
  if available("GUARD_SPEC") and not setupUses[enemyIndex].GUARD_SPEC
      and not enemy.mist and playerCanLowerStats(battle) then
    return use("GUARD_SPEC")
  end
  return nil
end

local function rematchTrainerAIAction(battle, restoreLimit)
  local item = chooseRematchTrainerItem(battle, restoreLimit)
  if item then return { special = "aiItem", item = item } end
  return nil
end

local function getBossRematchCount(mod, key)
  local counts = {}
  if mod.save and type(mod.save.get) == "function" then
    local ok, saved = pcall(mod.save.get, mod.save, BOSS_COUNT_STORE, {})
    if ok and type(saved) == "table" then counts = saved end
  end
  return math.max(0, math.floor(tonumber(counts[key]) or 0))
end

local function setBossRematchCount(mod, key, count)
  local counts = {}
  if mod.save and type(mod.save.get) == "function" then
    local ok, saved = pcall(mod.save.get, mod.save, BOSS_COUNT_STORE, {})
    if ok and type(saved) == "table" then
      for id, value in pairs(saved) do counts[id] = value end
    end
  end
  counts[key] = math.max(0, math.floor(tonumber(count) or 0))
  if mod.save and type(mod.save.set) == "function" then
    local ok, err = pcall(mod.save.set, mod.save, BOSS_COUNT_STORE, counts)
    if not ok and mod.log and mod.log.warn then
      mod.log:warn("boss rematch count could not be saved: " .. tostring(err))
    end
  end
end

local function getNpcRematchKey(overworld, npc, info)
  local d = npc and npc.def or {}
  local map = overworld and overworld.map
  local mapId = map and (map.id or (map.def and (map.def.id or map.def.label)))
  -- Match the engine's stable per-object save key convention.
  local objectIndex = d.index or d.objectId or d.object_id or (npc and npc.id)
  if objectIndex ~= nil then
    return tostring(mapId or "unknown-map") .. "_obj_" .. tostring(objectIndex)
  end
  return tostring(mapId or "unknown-map") .. "_trainer_"
    .. tostring((info and info.classId) or d.trainerClass or "unknown")
end

local localRematchCounts = {}
local function getRematchCount(mod, key)
  local counts = localRematchCounts
  if mod.save and type(mod.save.get) == "function" then
    local ok, saved = pcall(mod.save.get, mod.save, REMATCH_COUNT_STORE, {})
    if ok and type(saved) == "table" then counts = saved end
  end
  return math.max(0, math.floor(tonumber(counts[key]) or 0))
end

local function setRematchCount(mod, key, count)
  local nextCounts = {}
  local stored = localRematchCounts
  if mod.save and type(mod.save.get) == "function" then
    local ok, saved = pcall(mod.save.get, mod.save, REMATCH_COUNT_STORE, {})
    if ok and type(saved) == "table" then stored = saved end
  end
  for id, value in pairs(stored) do nextCounts[id] = value end
  nextCounts[key] = math.max(0, math.floor(tonumber(count) or 0))
  localRematchCounts = nextCounts
  if mod.save and type(mod.save.set) == "function" then
    local ok, err = pcall(mod.save.set, mod.save, REMATCH_COUNT_STORE, nextCounts)
    if not ok and mod.log and mod.log.warn then
      mod.log:warn("trainer rematch count could not be saved: " .. tostring(err))
    end
  end
end

-- a percentage of a whole, rounded down; nil-safe for callers that have
-- no configured option yet
local function scaleByPercent(value, pct)
  return math.floor((value or 0) * (pct or 0) / 100)
end

-- a marked rematch team (rematchIndex) wins over the trainer's own party;
-- fallback is the npc's usual party index
local function resolvePartyIndex(record, fallback)
  local marked = record and record.rematchIndex
  if marked then
    if record.parties and record.parties[marked] then return marked end
    if record.trainers and record.trainers[marked] then return marked end
  end
  return fallback
end

local function resolveParty(record, index)
  if not record or not index then return nil end
  if record.parties and record.parties[index] then return record.parties[index] end
  if record.trainers and record.trainers[index] then
    return record.trainers[index].party or record.trainers[index].roster
  end
  return nil
end

local function resolveLine(classId)
  local key = normalizeClassId(classId)
  return (key and REMATCH_LINES[key]) or REMATCH_LINES[classId] or DEFAULT_LINE
end

local function resolveDecline(classId)
  local key = normalizeClassId(classId)
  return (key and REMATCH_DECLINES[key]) or REMATCH_DECLINES[classId] or DEFAULT_DECLINE
end

-- the prize line filtered out of rematch victory queues
local function isPrizeLine(text)
  return type(text) == "string" and text:find("got ", 1, true) ~= nil
    and text:find("for winning", 1, true) ~= nil
end

-- Leader flags and badge events for Gen 2 and Gen 1.  The badge a leader hands
-- over IS their beaten state on Gen 2 (the ENGINE_*BADGE id and the badge's
-- wJohtoBadges bit are the same write), so the badge name is the whole record
-- of "this leader is finished" -- the ids are not repeated here, because the
-- ENGINE_* numbering moves between Gold and Crystal.
local LEADER_PATTERNS = {
  FALKNER  = { class = "FALKNER", event = 1213, badge = "ZEPHYR" },
  BUGSY    = { class = "BUGSY", event = 1214, badge = "HIVE" },
  WHITNEY  = { class = "WHITNEY", event = 1215, badge = "PLAIN" },
  MORTY    = { class = "MORTY", event = 1216, badge = "FOG" },
  JASMINE  = { class = "JASMINE", event = 1217, badge = "MINERAL" },
  CHUCK    = { class = "CHUCK", event = 1218, badge = "STORM" },
  PRYCE    = { class = "PRYCE", event = 1219, badge = "GLACIER" },
  CLAIR    = { class = "CLAIR", event = 1220, badge = "RISING" },
  BROCK    = { class = "BROCK", event = 1221, badge = "BOULDER" },
  MISTY    = { class = "MISTY", event = 1222, badge = "CASCADE" },
  SURGE    = { class = "LT_SURGE", event = 1223, badge = "THUNDER" },
  LT_SURGE = { class = "LT_SURGE", event = 1223, badge = "THUNDER" },
  LTSURGE  = { class = "LT_SURGE", event = 1223, badge = "THUNDER" },
  ERIKA    = { class = "ERIKA", event = 1224, badge = "RAINBOW" },
  JANINE   = { class = "JANINE", event = 1225, badge = "SOUL" },
  SABRINA  = { class = "SABRINA", event = 1226, badge = "MARSH" },
  BLAINE   = { class = "BLAINE", event = 1227, badge = "VOLCANO" },
  BLUE     = { class = "BLUE", event = 1228, badge = "EARTH" },
  RED      = { class = "RED", event = 1890 },
  WILL     = { class = "WILL" },
  KOGA     = { class = "KOGA" },
  BRUNO    = { class = "BRUNO" },
  KAREN    = { class = "KAREN" },
  LANCE    = { class = "CHAMPION" },
  CHAMPION = { class = "CHAMPION" },
}

local function matchLeaderPattern(str)
  if not str or type(str) ~= "string" then return nil end
  local upper = str:upper()
  for name, leader in pairs(LEADER_PATTERNS) do
    if upper:find(name, 1, true) then
      return leader
    end
  end
  return nil
end

-- the Gym Leader record a trainer class belongs to, if the class is one
local function resolveLeader(classId)
  local key = normalizeClassId(classId)
  if key and key:sub(1, 4) == "OPP_" then key = key:sub(5) end
  return (key and LEADER_PATTERNS[key]) or (classId and LEADER_PATTERNS[classId])
end

-- ------------------------------------------------------------- badge stores
--
-- Gen 2 keeps the sixteen badges on the player: the Johto eight in
-- save.player.badges and the Kanto eight in save.player.kantoBadges, keyed by
-- name (World:setEngineFlag routes an ENGINE_*BADGE id to the badge's own
-- name), with the badge's bit position accepted as the fallback key, which is
-- how FieldMoves.hasBadge and Battle:hasBadge read a converted cart save.
-- Gen 1 keeps them as bag items instead (src/inventory/Badges.lua writes
-- save.inventory["BOULDERBADGE"]).
local JOHTO_BADGE_ORDER = {
  "ZEPHYR", "HIVE", "PLAIN", "FOG", "MINERAL", "STORM", "GLACIER", "RISING",
}
local KANTO_BADGE_ORDER = {
  "BOULDER", "CASCADE", "THUNDER", "RAINBOW",
  "SOUL", "MARSH", "VOLCANO", "EARTH",
}

-- which save store holds this badge, and its bit position inside it
local function badgeStoreOf(name)
  for index, badge in ipairs(JOHTO_BADGE_ORDER) do
    if badge == name then return "badges", index end
  end
  for index, badge in ipairs(KANTO_BADGE_ORDER) do
    if badge == name then return "kantoBadges", index end
  end
  return nil
end

-- true when the badge is in hand, false when the store is there and the player
-- does not have it, nil when this save carries no badge store this build can
-- read.  Callers only let the definite false change anything, so an unfamiliar
-- save layout can never cost a rematch that used to be offered.
local function badgeOwned(self, name)
  if not name then return nil end
  local save = (self and self.game and self.game.save) or (self and self.save)
  if not save then
    local ok, Game = pcall(require, "src.core.Game")
    if ok and Game and Game.save then save = Game.save end
  end
  if not save then return nil end

  local store, position = badgeStoreOf(name)
  local owned = store and save.player and save.player[store]
  if type(owned) == "table" then
    if owned[name] then return true end
    if position and owned[position] == true then return true end
    return false
  end

  local inventory = save.inventory
  if type(inventory) == "table" then
    return (inventory[name] or inventory[name .. "BADGE"]) and true or false
  end

  return nil
end

-- ------------------------------------------------- "still owes" this talk
--
-- On Gold/Silver/Crystal a beaten Gym Leader is not finished with the player
-- yet: the battle only sets EVENT_BEAT_<leader>, and the badge (and often a TM)
-- follows from their own talk.  Whitney is the plain case -- she cries, blocks
-- the door, and only hands over PLAINBADGE on the talk after the trip-wire at
-- (8,5) -- while Falkner and the rest of the Johto leaders re-offer their TM to
-- a party that was full, Erika and Janine hand theirs over on a later talk, and
-- Clair's RISINGBADGE comes from the Dragon's Den elder with her TM still to
-- come.  Taking one of those talks for the rematch prompt is what left players
-- unable to get the badge at all (and would quietly cost the TM), so a leader
-- keeps their own conversation until the script has nothing left to give.
--
-- The walk below follows only what it understands: event and engine-flag
-- checks, the branches they select, and the ops that are pure talk.  Anything
-- else -- a setevent, a giveitem, an op that needs the VM -- counts as
-- unfinished business, so a script this mod cannot read keeps its talk rather
-- than losing whatever it was going to hand over.
local TALK_ONLY_OPS = {
  faceplayer = true, opentext = true, writetext = true, waitbutton = true,
  promptbutton = true, closetext = true, playsound = true, waitsfx = true,
  waitfanfare = true, itemnotify = true, getitemname = true, turnobject = true,
  showemote = true, applymovement = true, pause = true, wait = true,
  yesorno = true, jumptext = true, jumptextfaceplayer = true,
  ["end"] = true,
}
local CHECK_OPS = { checkevent = true, checkflag = true }
local BRANCH_OPS = { iftrue = true, iffalse = true }
local JUMP_OPS = { jump = true, sjump = true, farsjump = true }
local TALK_DEPTH_LIMIT = 8

local function talkStillHandsOver(ops, allScripts, ctx, depth)
  depth = depth or 0
  if type(ops) ~= "table" or depth > TALK_DEPTH_LIMIT then return true end
  local pending
  for _, cmd in ipairs(ops) do
    if type(cmd) == "table" then
      local op = cmd.op
      if op == "end" then return false end
      if CHECK_OPS[op] then
        pending = ctx.check(op, cmd.event or cmd.flag)
      elseif BRANCH_OPS[op] then
        -- the VM jumps out of the list when the branch is taken, so the
        -- target answers for the whole talk
        local taken = (op == "iftrue") == (pending == true)
        pending = nil
        if taken then
          local target = cmd.script
          if type(target) == "string" then target = allScripts[target] end
          return talkStillHandsOver(target, allScripts, ctx, depth + 1)
        end
      elseif op == "scall" then
        -- a call returns: unfinished business inside it is the talk's too
        local target = type(cmd.script) == "string" and allScripts[cmd.script] or cmd.script
        if talkStillHandsOver(target, allScripts, ctx, depth + 1) then return true end
      elseif JUMP_OPS[op] then
        local target = type(cmd.script) == "string" and allScripts[cmd.script] or cmd.script
        return talkStillHandsOver(target, allScripts, ctx, depth + 1)
      elseif not TALK_ONLY_OPS[op] then
        return true
      end
    end
  end
  return false
end

-- the Gen 2 script pool the NPC defs point into (extractTrainerInfo reads the
-- same one); nil on Gen 1, which has no such table and no multi-talk hand-over
local function gen2ScriptPool(self, game)
  if self and type(self.scripts) == "table" then return self.scripts end
  if self and self.vm and type(self.vm.scripts) == "table" then return self.vm.scripts end
  if game and game.data and type(game.data.gen2Scripts) == "table" then
    return game.data.gen2Scripts
  end
  return nil
end

-- what checkevent / checkflag answer for the live save
local function talkContext(self, game)
  local save = (self and self.game and self.game.save) or (self and self.save)
      or (game and game.save)
  local events = (self and self.events) or (save and save.events)
  local function eventSet(id)
    if id == nil or type(events) ~= "table" or type(events.get) ~= "function" then
      return false
    end
    local ok, value = pcall(events.get, events, id)
    return ok and value and true or false
  end
  local function flagSet(id)
    if id == nil then return false end
    if self and type(self.engineFlag) == "function" then
      local ok, value = pcall(self.engineFlag, self, id)
      if ok and value ~= nil then return value and true or false end
    end
    local flags = save and save.engineFlags
    return type(flags) == "table" and flags[id] == true or false
  end
  return {
    check = function(op, id)
      if op == "checkevent" then return eventSet(id) end
      return flagSet(id)
    end,
  }
end

-- a beaten Gym Leader whose badge the player does not hold yet, or whose
-- script still hands something over, keeps their own conversation
local function leaderStillHandingOver(self, game, classId, d)
  local leaderInfo = resolveLeader(classId)
  if not (leaderInfo and leaderInfo.badge) then return false end

  local owned = badgeOwned(self, leaderInfo.badge)
  if owned == false then return true end
  if owned ~= true then return false end

  local allScripts = gen2ScriptPool(self, game)
  local ops = allScripts and d and d.scriptKey and allScripts[d.scriptKey]
  if type(ops) ~= "table" then return false end
  return talkStillHandsOver(ops, allScripts, talkContext(self, game))
end

local function scanScriptForTrainer(scriptList, allScripts, visited)
  if not scriptList or type(scriptList) ~= "table" then return nil end
  visited = visited or {}
  local foundClass, foundMember, foundEvent
  for _, cmd in ipairs(scriptList) do
    if type(cmd) == "table" then
      local op = cmd.op
      if op == "loadtrainer" then
        foundClass = cmd.class or (cmd.args and cmd.args[1])
        foundMember = cmd.member or (cmd.args and cmd.args[2])
      elseif op == "checkevent" or op == "checkflag" then
        if not foundEvent then
          foundEvent = cmd.event or cmd.flag or (cmd.args and cmd.args[1])
        end
      elseif (op == "iftrue" or op == "iffalse" or op == "jump" or op == "farsjump") and cmd.script then
        if type(cmd.script) == "table" then
          local subClass, subMember, subEvent = scanScriptForTrainer(cmd.script, allScripts, visited)
          foundClass = foundClass or subClass
          foundMember = foundMember or subMember
          foundEvent = foundEvent or subEvent
        elseif type(cmd.script) == "string" and allScripts and not visited[cmd.script] then
          visited[cmd.script] = true
          local subClass, subMember, subEvent = scanScriptForTrainer(allScripts[cmd.script], allScripts, visited)
          foundClass = foundClass or subClass
          foundMember = foundMember or subMember
          foundEvent = foundEvent or subEvent
        end
      end
    end
  end
  return foundClass, foundMember, foundEvent
end

-- Helper to extract class, member index, and party records across Gen 1 and Gen 2 NPC structures
local function extractTrainerInfo(npc, game, overworld)
  local d = npc and npc.def
  if not d then return nil end

  local rawClass = d.trainerClass
  local partyIndex = d.trainerParty or 1
  local trainerEvent = nil

  if not rawClass and d.trainer then
    rawClass = d.trainer.class
    partyIndex = d.trainer.member or 1
    trainerEvent = d.trainer.event
  end

  -- If not on NPC definition, inspect script or match Gym Leader/Boss patterns
  if not rawClass then
    local allScripts = (overworld and overworld.scripts)
        or (overworld and overworld.vm and overworld.vm.scripts)
        or (game and game.data and (game.data.gen2Scripts or game.data.scripts))
    if d.scriptKey and allScripts and allScripts[d.scriptKey] then
      local scClass, scMember, scEvent = scanScriptForTrainer(allScripts[d.scriptKey], allScripts)
      if scClass then
        rawClass = scClass
        partyIndex = scMember or partyIndex
        trainerEvent = scEvent
      end
    end

    if not rawClass then
      local leader = matchLeaderPattern(d.sprite)
          or matchLeaderPattern(d.spriteName)
          or matchLeaderPattern(d.scriptKey)
          or matchLeaderPattern(d.text)
      if leader then
        rawClass = leader.class
        trainerEvent = leader.event
      end
    end
  end

  if not rawClass then return nil end

  local trainers = game and game.data and (game.data.trainers or game.data.gen2Trainers)
  local classRecord = nil
  if trainers then
    if trainers[rawClass] then
      classRecord = trainers[rawClass]
    elseif trainers.classes then
      if trainers.classes[rawClass] then
        classRecord = trainers.classes[rawClass]
      elseif type(rawClass) == "number" then
        for _, cls in pairs(trainers.classes) do
          if type(cls) == "table" and cls.index == rawClass then
            classRecord = cls
            break
          end
        end
      end
    end
  end

  local classId = (classRecord and (classRecord.id or classRecord.name)) or rawClass
  local team = resolveParty(classRecord, partyIndex)

  return {
    rawClass = rawClass,
    classId = classId,
    partyIndex = partyIndex,
    classRecord = classRecord,
    team = team,
    trainerEvent = trainerEvent,
    index = d.index,
    scriptKey = d.scriptKey or (d.trainer and d.trainer.scriptKey),
  }
end

-- Helper to determine if an NPC trainer is defeated across Gen 1 and Gen 2 world states
local function isTrainerDefeated(self, npc, info)
  if not npc or not npc.def then return false end
  local d = npc.def
  info = info or extractTrainerInfo(npc, (self and self.game), self)
  local classId = info and info.classId

  -- 1. Defeated check via Overworld methods (only accept true, fall through on false/nil)
  if self.trainerDefeated then
    local ok, defeated = pcall(self.trainerDefeated, self, npc)
    if ok and defeated == true then return true end
  end
  if self.trainerBeaten then
    local ok, beaten = pcall(self.trainerBeaten, self, d.trainer or d)
    if ok and beaten == true then return true end
  end

  local norm = classId and normalizeClassId(classId)
  if norm and norm:sub(1, 4) == "OPP_" then norm = norm:sub(5) end
  local leaderInfo = resolveLeader(classId)

  -- 2. Check the leader's badge via self:hasBadge
  if leaderInfo and leaderInfo.badge and self.hasBadge then
    local ok, has = pcall(self.hasBadge, self, leaderInfo.badge)
    if ok and has then return true end
  end

  -- 3. Event flags in self.events or self.game.save.events
  local events = self.events or (self.game and self.game.save and self.game.save.events)
  if events then
    local function checkFlag(flag)
      if not flag then return false end
      if events.get then
        local ok, v = pcall(events.get, events, flag)
        if ok and v then return true end
      end
      if type(events) == "table" and events[flag] then return true end
      return false
    end

    if info and info.trainerEvent and checkFlag(info.trainerEvent) then
      return true
    end
    if d.trainer and d.trainer.event and checkFlag(d.trainer.event) then
      return true
    end
    if leaderInfo and leaderInfo.event and checkFlag(leaderInfo.event) then
      return true
    end
  end

  -- 4. The leader's badge, in whichever store this save keeps it
  if leaderInfo and leaderInfo.badge and badgeOwned(self, leaderInfo.badge) == true then
    return true
  end

  -- 5. Gen 1 numeric bitmask badges
  local save = (self.game and self.game.save) or self.save
  if not save then
    local ok, Game = pcall(require, "src.core.Game")
    if ok and Game and Game.save then save = Game.save end
  end
  local badges = save and ((save.player and save.player.badges) or save.badges)
  if save and norm then
    local GEN1_BADGE_BITS = {
      BROCK = 1, MISTY = 2, LT_SURGE = 4, LTSURGE = 4,
      ERIKA = 8, KOGA = 16, SABRINA = 32, BLAINE = 64, GIOVANNI = 128,
    }
    local bitMask = GEN1_BADGE_BITS[norm]
    if bitMask and type(badges) == "number" then
      if math.floor(badges / bitMask) % 2 == 1 then return true end
    end
  end

  return false
end

-- Active rematch flags.  Gen 1's party hook is scoped to the single
-- BattleState.newTrainer call; Gen 2 keeps its existing script flag.
local activeRematch = nil
local activeGen1Rematch = nil

return function(mod)
  mod.exports.resolveLine = resolveLine
  mod.exports.resolveDecline = resolveDecline
  mod.exports.resolveWarning = resolveWarning
  mod.exports.normalizeClassId = normalizeClassId
  mod.exports.levelGap = levelGap
  mod.exports.buildRandomRematchParty = buildRandomRematchParty
  mod.exports.buildBossRematchParty = buildBossRematchParty
  mod.exports.chooseRematchTrainerItem = chooseRematchTrainerItem
  mod.exports.rematchTrainerAIAction = rematchTrainerAIAction
  mod.exports.collectRandomizableMoves = collectRandomizableMoves
  mod.exports.speciesTypes = speciesTypes
  mod.exports.isPrizeLine = isPrizeLine
  mod.exports.scaleByPercent = scaleByPercent
  mod.exports.resolvePartyIndex = resolvePartyIndex
  mod.exports.resolveParty = resolveParty
  mod.exports.extractTrainerInfo = extractTrainerInfo
  mod.exports.isTrainerDefeated = isTrainerDefeated
  mod.exports.resolveLeader = resolveLeader
  mod.exports.badgeOwned = badgeOwned
  mod.exports.talkStillHandsOver = talkStillHandsOver

  -- rematch earnings: a percentage of the usual battle money and
  -- experience, stepped in 10% intervals.  Money defaults to 0% (the
  -- original no-prize rematch behaviour); XP defaults to 100%, so
  -- behaviour is unchanged until the player moves the slider.
  mod.options:define({
    { key = "rematchMoneyPct", type = "number", label = "REMATCH MONEY %",
      min = 0, max = 100, step = 10, default = 0 },
    { key = "rematchXpPct", type = "number", label = "REMATCH XP %",
      min = 0, max = 100, step = 10, default = 100 },
  })

  -- Rematch battle items are selected by a battle-state-aware wrapper below.
  -- This avoids the engine's single-static-item ai_classes contract and lets
  -- the AI use all requested Gen 1 items contextually.

  -- Professor Oak is added to the live Gen 1 trainer table in install(game).
  -- That keeps this Gen 1-only class out of the Gen 2 trainer registry.

  -- Trainer-party hooks receive copied roster data.  The active context is
  -- set only during the accepted Gen 1 rematch's constructor call, so normal
  -- first battles and all Gen 2 scripts pass through unchanged.
  mod.hooks:wrap("trainer.party", function(nextParty, trainerClass, partyIndex, party)
    local original = nextParty(trainerClass, partyIndex, party) or party
    local active = activeGen1Rematch
    if not active then return original end
    if trainerClass ~= active.trainerClass
        or (partyIndex or 1) ~= (active.partyIndex or 1) then
      return original
    end
    return active.party or original
  end)

  local function installRematchBattleAI(BattleState)
    if not BattleState then return end
    if not BattleState._trainerRematchBattleAIWrapped then
      BattleState._trainerRematchBattleAIWrapped = true
      local vanillaTrainerAIAction = BattleState.trainerAIAction
      if type(vanillaTrainerAIAction) == "function" then
        BattleState.trainerAIAction = function(self, ...)
          if self and self.rematch then
            local restoreLimit = self.isBossRematch and BOSS_RESTORE_USES
                or REMATCH_RESTORE_USES
            return rematchTrainerAIAction(self, restoreLimit)
          end
          return vanillaTrainerAIAction(self, ...)
        end
      end
      local vanillaAiUsesFor = BattleState.aiUsesFor
      if type(vanillaAiUsesFor) == "function" then
        BattleState.aiUsesFor = function(self, ...)
          if self and self.rematch then
            return tonumber(self.rematchAIUses)
                or (self.isBossRematch and BOSS_REMATCH_AI_USES or REMATCH_AI_USES)
          end
          return vanillaAiUsesFor(self, ...)
        end
      end
    end

    -- Gen 1's X ACCURACY is a battle-wide never-miss flag rather than a
    -- conventional accuracy stage. The current engine's item executor
    -- handles the item message/SFX but leaves the flag to this compatibility
    -- bridge, which mirrors Damage.accuracyThreshold's expected battler field.
    local ok, TrainerAI = pcall(require, "src.battle.TrainerAI")
    if ok and TrainerAI and type(TrainerAI.useItem) == "function"
        and not TrainerAI._trainerRematchXAccuracyWrapped then
      TrainerAI._trainerRematchXAccuracyWrapped = true
      local vanillaUseItem = TrainerAI.useItem
      TrainerAI.useItem = function(battle, item, ...)
        local messages = vanillaUseItem(battle, item, ...)
        if item == "X_ACCURACY" and battle and battle.rematch and battle.enemy then
          battle.enemy.xAccuracy = true
        end
        return messages
      end
    end
  end

  local KANTO_BOSS_GYMS = {
    { label = "BROCK", class = "OPP_BROCK", badge = "BOULDER", focusType = "ROCK", aceCap = BOSS_ACE_CAP },
    { label = "MISTY", class = "OPP_MISTY", badge = "CASCADE", focusType = "WATER", aceCap = BOSS_ACE_CAP },
    { label = "LT. SURGE", class = "OPP_LT_SURGE", badge = "THUNDER", focusType = "ELECTRIC", aceCap = BOSS_ACE_CAP },
    { label = "ERIKA", class = "OPP_ERIKA", badge = "RAINBOW", focusType = "GRASS", aceCap = BOSS_ACE_CAP },
    { label = "KOGA", class = "OPP_KOGA", badge = "SOUL", focusType = "POISON", aceCap = BOSS_ACE_CAP },
    { label = "SABRINA", class = "OPP_SABRINA", badge = "MARSH", focusType = "PSYCHIC", aceCap = BOSS_ACE_CAP },
    { label = "BLAINE", class = "OPP_BLAINE", badge = "VOLCANO", focusType = "FIRE", aceCap = BOSS_ACE_CAP },
    { label = "GIOVANNI", class = "OPP_GIOVANNI", badge = "EARTH", partyIndex = 3, focusType = "GROUND", aceCap = BOSS_ACE_CAP },
  }
  local KANTO_ELITE = {
    { label = "LORELEI", class = "OPP_LORELEI", focusType = "ICE", aceCap = BOSS_ACE_CAP },
    { label = "BRUNO", class = "OPP_BRUNO", focusType = "FIGHTING", aceCap = BOSS_ACE_CAP },
    { label = "AGATHA", class = "OPP_AGATHA", focusType = "GHOST", aceCap = BOSS_ACE_CAP },
    { label = "LANCE", class = "OPP_LANCE", focusType = "DRAGON", aceCap = BOSS_ACE_CAP },
  }

  local function isSetFlag(value)
    return value == true or value == 1 or value == "1"
  end

  local function gameFlag(game, flag)
    local save = game and game.save
    local stores = { save and save.flags, save and save.events, save and save.engineFlags }
    for _, store in pairs(stores) do
      if type(store) == "table" and isSetFlag(store[flag]) then return true end
    end
    return false
  end

  local function hasChampionFlag(game)
    return gameFlag(game, "EVENT_BEAT_CHAMPION_RIVAL")
  end

  local function rivalPartyIndex(game)
    local save = game and game.save or {}
    local starter = save.rivalStarter or (save.player and save.player.rivalStarter)
    if type(starter) == "string" then
      starter = starter:upper()
      if starter:find("CHARMANDER", 1, true) then return 1 end
      if starter:find("SQUIRTLE", 1, true) then return 2 end
      if starter:find("BULBASAUR", 1, true) then return 3 end
    elseif tonumber(starter) and tonumber(starter) >= 1 and tonumber(starter) <= 3 then
      return math.floor(tonumber(starter))
    end
    if gameFlag(game, "EVENT_CHOSE_CHARMANDER") then return 1 end
    if gameFlag(game, "EVENT_CHOSE_SQUIRTLE") then return 2 end
    if gameFlag(game, "EVENT_CHOSE_BULBASAUR") then return 3 end
    return 1
  end

  local function oakUnlocked()
    if mod.save and type(mod.save.get) == "function" then
      local ok, value = pcall(mod.save.get, mod.save, OAK_UNLOCK_STORE, false)
      return ok and value == true
    end
    return false
  end

  local function setOakUnlocked()
    if mod.save and type(mod.save.set) == "function" then
      pcall(mod.save.set, mod.save, OAK_UNLOCK_STORE, true)
    end
  end

  local function trainerRecord(game, classId)
    return game and game.data and game.data.trainers and game.data.trainers[classId]
  end

  local function addBossRow(rows, game, entry)
    local rec = trainerRecord(game, entry.class)
    local partyIndex = entry.partyIndex or 1
    if rec and not resolveParty(rec, partyIndex) then partyIndex = 1 end
    local party = rec and resolveParty(rec, partyIndex)
    if not party or #party == 0 then return end
    rows[#rows + 1] = {
      label = entry.label,
      right = "#" .. tostring(getBossRematchCount(mod, entry.class .. ":" .. tostring(partyIndex)) + 1),
      value = {
        trainerClass = entry.class, partyIndex = partyIndex, aceCap = entry.aceCap or BOSS_ACE_CAP,
        isOak = entry.isOak == true, unlockOakOnWin = entry.unlockOakOnWin == true,
        focusType = entry.focusType,
      },
    }
  end

  local function buildBossRows(game)
    local rows = {}
    for _, entry in ipairs(KANTO_BOSS_GYMS) do
      local owned = badgeOwned({ game = game }, entry.badge)
      local beatFlag = "EVENT_BEAT_" .. entry.class:gsub("^OPP_", "")
      if owned == true or gameFlag(game, beatFlag) then addBossRow(rows, game, entry) end
    end
    if hasChampionFlag(game) then
      for _, entry in ipairs(KANTO_ELITE) do addBossRow(rows, game, entry) end
      addBossRow(rows, game, {
        label = "RIVAL", class = "OPP_RIVAL3", partyIndex = rivalPartyIndex(game),
        aceCap = BOSS_ACE_CAP, unlockOakOnWin = true,
      })
      if oakUnlocked() then
        addBossRow(rows, game, {
          label = "PROF. OAK", class = "OPP_PROF_OAK", partyIndex = 1,
          aceCap = OAK_ACE_CAP, isOak = true,
        })
      end
    end
    return rows
  end

  local function startBossRematch(game, entry, menu, BattleState)
    local classId, partyIndex = entry.trainerClass, entry.partyIndex or 1
    local record = trainerRecord(game, classId)
    local sourceParty = record and resolveParty(record, partyIndex)
    if not sourceParty or #sourceParty == 0 then return false end
    local key = classId .. ":" .. tostring(partyIndex)
    local nextCount = getBossRematchCount(mod, key) + 1
    local team = buildBossRematchParty(game.data, sourceParty, nextCount, entry.aceCap,
      nil, { focusType = entry.focusType })
    if not team then return false end

    if menu and menu.close then menu:close() end
    local previousContext = activeGen1Rematch
    activeGen1Rematch = { trainerClass = classId, partyIndex = partyIndex, party = team }
    local ok, battle = pcall(BattleState.newTrainer, game, classId, partyIndex)
    activeGen1Rematch = previousContext
    if not ok or not battle then
      if mod.log and mod.log.warn then
        mod.log:warn("boss rematch battle could not be created for " .. tostring(classId) .. ": " .. tostring(battle))
      end
      return false
    end

    -- Gym/E4/Champion battles have built-in special-move overrides. Replace
    -- each constructed enemy Pokémon's move array after construction so a
    -- boss rematch always keeps its four newly randomized moves.
    for i, slot in ipairs(team) do
      local enemyMon = battle.enemyParty and battle.enemyParty[i]
      if enemyMon then
        local randomMoves = {}
        for _, moveId in ipairs(slot.moves or {}) do
          local moveDef = game.data.moves and game.data.moves[moveId]
          if moveDef then
            randomMoves[#randomMoves + 1] = { id = moveId, pp = moveDef.pp or 0 }
          end
        end
        enemyMon.moves = randomMoves
        if battle.enemy and battle.enemy.mon == enemyMon then
          battle.enemy.curMoves = randomMoves
        end
      end
    end

    battle.rematch = true
    battle.isBossRematch = true
    battle.rematchAIUses = BOSS_REMATCH_AI_USES
    battle.aiUses = BOSS_REMATCH_AI_USES
    setBossRematchCount(mod, key, nextCount)
    local previousOnFinish = battle.onFinish
    battle.onFinish = function(result, ...)
      if previousOnFinish then previousOnFinish(result, ...) end
      if entry.unlockOakOnWin and result == "win" then setOakUnlocked() end
    end

    -- The Start menu is normally still underneath the boss list. Close it
    -- before returning control to the overworld's normal battle push path.
    local top = game.stack and game.stack.top and game.stack:top()
    if top and not top.pushBattle and game.stack.pop then
      pcall(game.stack.pop, game.stack)
      top = game.stack:top()
    end
    if top and type(top.pushBattle) == "function" then
      top:pushBattle(battle)
    elseif game.stack and game.stack.push then
      game.stack:push(battle)
    end
    return true
  end

  mod.exports.buildBossRows = buildBossRows
  mod.exports.startBossRematch = startBossRematch

  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    items = next(game, items) or items
    if not (game and game.data and game.data.trainers and game.data.trainers.OPP_BROCK) then
      return items
    end
    return mod.ui.insertBefore(items, "OPTION", {
      label = "BOSS REMATCH",
      onSelect = function()
        local rows = buildBossRows(game)
        if #rows == 0 then
          local TextBox = require("src.render.TextBox")
          game.stack:push(TextBox.new(game, "No boss rematches\nare unlocked yet."))
          return
        end
        local ListMenu = require("src.ui.ListMenu")
        local bossMenu = ListMenu.new(game, "BOSS REMATCH", rows, {
          onChoose = function(item, listMenu)
            if not item or not item.value then return end
            startBossRematch(game, item.value, listMenu, require("src.battle.BattleState"))
          end,
        })
        game.stack:push(bossMenu)
      end,
    })
  end)

  local function resolveActiveGame(self, game, deps)
    if self and self.game then return self.game end
    if game then return game end
    if deps and deps.game then return deps.game end
    if mod and mod.world and mod.world.game then return mod.world.game end
    local ok, Game = pcall(require, "src.core.Game")
    if ok and Game then return Game end
    return nil
  end

  local function offerRematch(self, npc, game, deps)
    deps = deps or {}
    local activeGame = resolveActiveGame(self, game, deps)
    local d = npc.def
    local TextBox = deps.textBox or require("src.render.TextBox")
    local Runtime = deps.runtime or require("src.mods.Runtime")
    local BattleState = deps.battleState or (pcall(require, "src.battle.BattleState") and require("src.battle.BattleState"))
    npc.frozen = true
    if npc.facePlayer then npc:facePlayer(self.player) end
    local unfreeze = function() npc.frozen = false end

    local info = extractTrainerInfo(npc, activeGame, self)
    local classId = info and info.classId or (d and d.trainerClass)

    local function decline()
      -- the class reacts to the NO: mocking, or understanding for the
      -- wise classes.  The trainer's vanilla post-battle line follows as
      -- a second page, so the base-game text is never lost.
      local header = activeGame and activeGame.data and activeGame.data.trainerHeader
          and activeGame.data:trainerHeader(self.map and self.map.def and self.map.def.label, d.index)
      local after = header and header.after and activeGame.data.text and activeGame.data.text[header.after]
      local line = resolveDecline(classId)
      if after then line = line .. "\f" .. after end
      activeGame.stack:push(TextBox.new(activeGame, line, unfreeze))
    end

    local function accept()
      -- a mod may ship a dedicated rematch team for the class: the
      -- trainer record's rematchIndex points at it (Yellow Legacy Changes
      -- appends the hack's L64-77 rematch teams this way).  Fall back to
      -- the trainer's own party when none is marked.
      local partyIndex = resolvePartyIndex(info and info.classRecord, info and info.partyIndex or d.trainerParty)
      local team = resolveParty(info and info.classRecord, partyIndex) or (info and info.team)
      local gen1Path = not self.startTrainerScript and self.pushBattle
          and BattleState and BattleState.newTrainer
      local npcKey = gen1Path and getNpcRematchKey(self, npc, info) or nil
      local previousCount = npcKey and getRematchCount(mod, npcKey) or 0
      local nextCount = previousCount + 1
      local randomizedTeam = gen1Path and buildRandomRematchParty(
        activeGame and activeGame.data, team, nextCount) or nil
      if gen1Path and not randomizedTeam and mod.log and mod.log.warn then
        mod.log:warn("could not build randomized party for trainer " .. tostring(info and info.classId)
          .. "; this rematch will use the trainer's original roster")
      end

      local function battle()
        Runtime.emit("world.trainer_engaged", {
          npc = npc,
          trainerClass = info and info.rawClass or d.trainerClass,
          partyIndex = partyIndex,
          trainerEvent = info and info.trainerEvent,
        })

        if self.startTrainerScript then
          -- Gen 2 engine overworld
          local REMATCH_SCRIPT = {
            { op = "loadtrainer", class = info and info.rawClass or d.trainerClass, member = partyIndex },
            { op = "startbattle" },
            { op = "reloadmapafterbattle" },
          }
          activeRematch = true
          self:startTrainerScript(npc, REMATCH_SCRIPT, nil)
        elseif self.pushBattle and BattleState and BattleState.newTrainer then
          -- Gen 1 engine overworld.  Supply a one-shot randomized party to
          -- the engine hook, then attach the hard item AI to this battle only.
          local trainerClass = info and info.rawClass or d.trainerClass
          local header = activeGame and activeGame.data and activeGame.data.trainerHeader
              and activeGame.data:trainerHeader(self.map and self.map.def and self.map.def.label, d.index)
          local wonText = header and header.won and activeGame.data.text and activeGame.data.text[header.won]
          local context = randomizedTeam and {
            trainerClass = trainerClass, partyIndex = partyIndex or 1,
            party = randomizedTeam,
          } or nil
          activeGen1Rematch = context
          local ok, b = pcall(BattleState.newTrainer, activeGame, trainerClass, partyIndex)
          activeGen1Rematch = nil
          if not ok or not b then
            if mod.log and mod.log.warn then
              mod.log:warn("trainer rematch battle could not be created: " .. tostring(b))
            end
            unfreeze()
            return
          end
          b.rematch = true
          b.endBattleText = wonText and TextBox.substitute and TextBox.substitute(activeGame, wonText) or nil
          b.rematchAIUses = REMATCH_AI_USES
          b.aiUses = REMATCH_AI_USES
          -- Count only an actual accepted battle (not a declined warning).
          -- The saved counter is per overworld object, not per trainer class.
          if npcKey and randomizedTeam then setRematchCount(mod, npcKey, nextCount) end
          b.onFinish = function(result)
            if self.afterBattle then self:afterBattle(result, b) end
            unfreeze()
          end
          self:pushBattle(b)
        else
          unfreeze()
        end
      end

      -- when the rematch team averages more than 10 levels above the
      -- player's party, the class warns in its own voice and asks again
      local playerParty = (activeGame and activeGame.save and activeGame.save.party)
          or (activeGame and activeGame.save and activeGame.save.player and activeGame.save.player.party)
      local warningTeam = randomizedTeam or team
      local gap = levelGap(playerParty, warningTeam)
      if gap and gap > 10 then
        activeGame.stack:push(TextBox.new(activeGame, resolveWarning(classId), nil, {
          choice = function(yes)
            if yes then battle() else decline() end
          end,
        }))
      else
        battle()
      end
    end

    activeGame.stack:push(TextBox.new(activeGame, resolveLine(classId), nil, {
      choice = function(yes)
        if yes then accept() else decline() end
      end,
    }))
    return true
  end

  -- deps injectable so the headless test can drive the wraps without the
  -- engine; in-game every one resolves to the real module
  local function install(game, deps)
    deps = deps or {}
    local Overworld = deps.overworld or require("src.world.OverworldController")
    local BattleState = deps.battleState or (pcall(require, "src.battle.BattleState") and require("src.battle.BattleState"))
    local mapScripts = deps.mapScripts or (pcall(require, "data.scripts.init") and require("data.scripts.init"))

    installRematchBattleAI(BattleState)

    if game and game.data and game.data.trainers and game.data.trainers.OPP_BROCK
        and not game.data.trainers.OPP_PROF_OAK then
      game.data.trainers.OPP_PROF_OAK = {
        id = "OPP_PROF_OAK", name = "PROF. OAK", baseMoney = 100,
        basePic = "OPP_SCIENTIST",
        parties = { {
          { species = "RHYDON", level = 78 }, { species = "EXEGGUTOR", level = 80 },
          { species = "ARCANINE", level = 82 }, { species = "GYARADOS", level = 84 },
          { species = "ALAKAZAM", level = 86 }, { species = "TAUROS", level = 88 },
        } },
      }
    end

    -- one wrap per boot; hot reload re-runs entry chunks without clearing
    -- the require cache, so the module table is the idempotence sentinel
    if Overworld and not Overworld._rematchTalkWrapped then
      Overworld._rematchTalkWrapped = true

      local vanillaTalkTo = Overworld.talkTo or function() return false end
      Overworld.talkTo = function(self, npc)
        local d = npc and npc.def
        if not d then return vanillaTalkTo(self, npc) end

        local activeGame = resolveActiveGame(self, game, deps)
        local info = extractTrainerInfo(npc, activeGame, self)
        if info and isTrainerDefeated(self, npc, info) then
          local scripted = mapScripts and mapScripts.talkScript
              and mapScripts.talkScript(self.map and self.map.id, d.text)
          local hasDedicatedRematch = resolvePartyIndex(info.classRecord, nil) ~= nil
          -- a leader who still owes a badge or a TM keeps the talk: the
          -- rematch prompt must not eat the only script that hands it over
          if not leaderStillHandingOver(self, activeGame, info.classId, d)
              and (not scripted or hasDedicatedRematch or d.scriptKey or self.startTrainerScript) then
            return offerRematch(self, npc, activeGame, deps)
          end
        end
        return vanillaTalkTo(self, npc)
      end
    end

    -- Gen 1 BattleState wraps: rematch money is a percentage of the usual prize
    -- (MODS > Trainer Rematch, 0-100% in 10s): scale the class base money for this battle
    -- only (never touch the shared data record), and at 0% drop the prize
    -- line entirely so no "You got ¥0" box appears
    if BattleState and not BattleState._rematchFaintedWrapped then
      BattleState._rematchFaintedWrapped = true

      local vanillaFainted = BattleState.enemyMonFainted
      if vanillaFainted then
        BattleState.enemyMonFainted = function(self, ...)
          if not self.rematch then return vanillaFainted(self, ...) end
          local realTrainer = self.trainer
          local pct = mod.options:get("rematchMoneyPct") or 0
          if realTrainer then
            self.trainer = setmetatable({
              baseMoney = scaleByPercent(realTrainer.baseMoney, pct),
            }, { __index = realTrainer })
          end
          local realSayNext = self.sayNext
          if pct <= 0 and realSayNext then
            self.sayNext = function(s, text)
              if isPrizeLine(text) then return end
              return realSayNext(s, text)
            end
          end
          local ok, err = pcall(vanillaFainted, self, ...)
          self.trainer = realTrainer
          self.sayNext = realSayNext
          if not ok then error(err, 2) end
        end
      end

      -- Pay Day is a reward too: nothing to collect on a rematch
      local vanillaFinish = BattleState.finish
      if vanillaFinish then
        BattleState.finish = function(self)
          if self.rematch then self.payDay = nil end
          return vanillaFinish(self)
        end
      end
    end

    -- Gen 2 Battle wraps: intercept prize money & battle construction on Gen 2
    local okGen2, Gen2Battle = pcall(require, "src.battle.gen2.Battle")
    if okGen2 and Gen2Battle and not Gen2Battle._rematchWrapped then
      Gen2Battle._rematchWrapped = true

      local vanillaBattleNew = Gen2Battle.new
      if vanillaBattleNew then
        Gen2Battle.new = function(opts)
          local b = vanillaBattleNew(opts)
          if b and (activeRematch or (opts and opts.rematch)) then
            b.rematch = true
            activeRematch = nil
          end
          return b
        end
      end

      local vanillaAwardPrize = Gen2Battle.awardPrizeMoney
      if vanillaAwardPrize then
        Gen2Battle.awardPrizeMoney = function(self)
          if not self.rematch then return vanillaAwardPrize(self) end
          local pct = mod.options:get("rematchMoneyPct") or 0
          if pct <= 0 then
            self.payDay = nil
            self.prize = { quarter = 0, total = 0, toMom = 0, mode = 0, wallet = 0, saved = 0 }
            return self.prize
          end
          local realTrainer = self.trainer
          if realTrainer then
            self.trainer = setmetatable({
              baseMoney = scaleByPercent(realTrainer.baseMoney, pct),
            }, { __index = realTrainer })
          end
          local ok, res = pcall(vanillaAwardPrize, self)
          self.trainer = realTrainer
          if not ok then error(res, 2) end
          return res
        end
      end
    end
  end
  mod.exports.install = install

  -- rematch experience scales the final gained EXP (default 100%).  The
  -- award ctx's applyShare takes a participant split, and the gain
  -- formula floors it through math.max(1, split): scaling that divisor
  -- by a percentage hits the floor for the usual single-participant
  -- battle (0% -> split 0 -> the max(1, .) guard restores full EXP).  The
  -- exp.gain hook sees the finished amount, so the award wrap only marks
  -- the battle as a rematch while vanilla runs and the exp.gain wrap does
  -- the scaling.
  local rematchXpPct
  mod.hooks:wrap("battle.exp_award", function(next, ctx)
    local saved = rematchXpPct
    rematchXpPct = ctx and ctx.battle and ctx.battle.rematch
        and (mod.options:get("rematchXpPct") or 100) or nil
    local ok, res = pcall(next, ctx)
    rematchXpPct = saved
    if not ok then error(res, 2) end
    return res
  end)
  mod.hooks:wrap("exp.gain", function(next, ctx)
    local pct = rematchXpPct
    if pct and pct ~= 100 then
      local gained = next(ctx)
      if gained == nil then return nil end
      return scaleByPercent(gained, pct)
    end
    return next(ctx)
  end)

  install()

  mod.events:on("game.ready", function(ev)
    install(ev.game)
  end)
end
