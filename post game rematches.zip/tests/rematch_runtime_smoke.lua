-- Standalone smoke checks for rematch helpers and the Gen 1 battle-AI bridge.
-- Run from the mod root with: texlua tests/rematch_runtime_smoke.lua

package.path = "./?.lua;./?/init.lua;" .. package.path

local BattleState = {
  trainerAIAction = function() return { special = "vanilla" } end,
  aiUsesFor = function() return 3 end,
  enemyMonFainted = function() end,
  finish = function() end,
}
local TrainerAI = {
  useItem = function() return { "mock item message" } end,
}
local Overworld = { talkTo = function() return false end }
package.preload["src.world.OverworldController"] = function() return Overworld end
package.preload["src.battle.BattleState"] = function() return BattleState end
package.preload["src.battle.TrainerAI"] = function() return TrainerAI end
package.preload["src.battle.Damage"] = function()
  return { statAtCap = function() return false end }
end
package.preload["data.scripts.init"] = function()
  return { talkScript = function() return false end }
end
package.preload["src.battle.gen2.Battle"] = function() return {} end

local mod = {
  exports = {},
  options = {
    define = function() end,
    get = function(_, key) if key == "rematchMoneyPct" then return 0 end return 100 end,
  },
  hooks = { wrap = function() end },
  events = { on = function() end },
  ui = { insertBefore = function(_, items, _, item)
    table.insert(items, item)
    return items
  end },
  save = {
    values = {},
    get = function(self, key, fallback)
      local value = self.values[key]
      if value == nil then return fallback end
      return value
    end,
    set = function(self, key, value) self.values[key] = value end,
  },
  log = { warn = function() end },
}

local entry = assert(loadfile("main.lua"))()
entry(mod)
local ex = mod.exports
assert(type(ex.buildRandomRematchParty) == "function")
assert(type(ex.buildBossRematchParty) == "function")
assert(type(ex.rematchTrainerAIAction) == "function")

local function mon(types)
  return { baseStats = { hp = 50, attack = 55, defense = 50, speed = 50, special = 55 },
           types = types }
end
local data = {
  pokemon = {
    BULBASAUR = mon({ "GRASS", "POISON" }), CHARMANDER = mon({ "FIRE" }),
    SQUIRTLE = mon({ "WATER" }), WARTORTLE = mon({ "WATER" }),
    ZAPDOS = mon({ "ELECTRIC", "FLYING" }), ZUBAT = mon({ "POISON", "FLYING" }),
    ONIX = mon({ "ROCK", "GROUND" }), GROWLITHE = mon({ "FIRE" }),
    PONYTA = mon({ "FIRE" }), KADABRA = mon({ "PSYCHIC" }),
  },
  moves = {
    TACKLE = { pp = 35, power = 35, accuracy = 95, type = "NORMAL" },
    EMBER = { pp = 25, power = 40, accuracy = 100, type = "FIRE" },
    WATER_GUN = { pp = 25, power = 40, accuracy = 100, type = "WATER" },
    VINE_WHIP = { pp = 10, power = 45, accuracy = 100, type = "GRASS" },
    THUNDER_SHOCK = { pp = 30, power = 40, accuracy = 70, type = "ELECTRIC" },
    WING_ATTACK = { pp = 35, power = 35, accuracy = 100, type = "FLYING" },
    ROCK_THROW = { pp = 15, power = 50, accuracy = 65, type = "ROCK" },
    PSYCHIC = { pp = 10, power = 90, accuracy = 100, type = "PSYCHIC" },
    GROWL = { pp = 40, power = 0, accuracy = 100, type = "NORMAL",
             effect = "ATTACK_DOWN1_EFFECT" },
  },
  items = {
    FULL_RESTORE = {}, X_ATTACK = {}, X_DEFEND = {}, X_SPEED = {},
    X_SPECIAL = {}, X_ACCURACY = {}, GUARD_SPEC = {}, DIRE_HIT = {},
  },
}
local function deterministic(index) return index and 1 or 1 end
local source = { { species = "RATTATA", level = 5 }, { species = "PIDGEY", level = 12 } }
local firstRegular = assert(ex.buildRandomRematchParty(data, source, 1, deterministic))
assert(firstRegular[1].level == 10 and firstRegular[2].level == 17,
  "first rematch adds five levels")
local secondRegular = assert(ex.buildRandomRematchParty(data, source, 2, deterministic))
assert(secondRegular[1].level == 15 and secondRegular[2].level == 22,
  "rematch count drives persistent +5 scaling")
local regular = assert(ex.buildRandomRematchParty(data, source, 20, deterministic))
assert(regular[1].level == 100 and regular[2].level == 100, "regular cap is 100")
local bossTemplate = {
  { species = "RATTATA", level = 78 }, { species = "PIDGEY", level = 80 },
  { species = "RATTATA", level = 82 }, { species = "PIDGEY", level = 84 },
  { species = "RATTATA", level = 86 }, { species = "PIDGEY", level = 88 },
}
local boss = assert(ex.buildBossRematchParty(data, bossTemplate, 60, 200, deterministic))
assert(boss[1].level == 100 and boss[5].level == 100 and boss[6].level == 200,
  "boss caps keep only the ace above 100")
local focused = assert(ex.buildBossRematchParty(data, bossTemplate, 1, 200,
  deterministic, { focusType = "FIRE" }))
local signatureCount, counterCount = 0, 0
local counters = { WATER = true, GROUND = true, ROCK = true }
for _, slot in ipairs(focused) do
  local hasCounter = false
  for _, typeId in ipairs(ex.speciesTypes(data.pokemon[slot.species])) do
    if typeId == "FIRE" then signatureCount = signatureCount + 1 end
    if counters[typeId] then hasCounter = true end
  end
  if hasCounter then counterCount = counterCount + 1 end
end
assert(signatureCount >= 3 and counterCount >= 2,
  "focused Gym Leader teams keep their signature and include counters")
local oak = assert(ex.buildBossRematchParty(data, bossTemplate, 80, 300, deterministic))
assert(oak[5].level == 100 and oak[6].level == 300, "Oak cap is 300 on ace only")
for _, slot in ipairs(regular) do
  for _, moveId in ipairs(slot.moves) do
    local move = assert(data.moves[moveId], "move ID exists")
    assert(move.power > 0 and move.pp > 0, "move is damaging and PP-bearing")
  end
end

local function itemBattle()
  return {
    rematch = true, aiUses = 11, enemyIndex = 1, data = data,
    enemy = {
      mon = { hp = 100, stats = { hp = 100 } },
      curMoves = { { id = "TACKLE" }, { id = "THUNDER_SHOCK" } },
      curStats = { attack = 50, defense = 50, speed = 10, special = 50 },
      stages = {},
    },
    player = {
      curMoves = { { id = "TACKLE" }, { id = "GROWL" } },
      curStats = { attack = 50, defense = 50, speed = 20, special = 50 },
      stages = {},
    },
  }
end
local b = itemBattle()
local action = BattleState.trainerAIAction(b)
assert(action and action.special == "aiItem" and action.item == "X_ACCURACY",
  "BattleState wrapper returns a native aiItem action")
TrainerAI.useItem(b, "X_ACCURACY")
assert(b.enemy.xAccuracy == true, "X Accuracy enables the never-miss flag")
local expected = { "X_ATTACK", "X_SPECIAL", "X_DEFEND", "X_SPEED", "GUARD_SPEC" }
for _, itemId in ipairs(expected) do
  local nextAction = ex.rematchTrainerAIAction(b, 5)
  assert(nextAction and nextAction.special == "aiItem" and nextAction.item == itemId,
    "contextual item choice: " .. itemId)
end
assert(ex.rematchTrainerAIAction(b, 5) == nil, "setup items are not repeatedly wasted")
local restoreBattle = itemBattle()
restoreBattle.enemy.mon.hp = 20
assert(ex.rematchTrainerAIAction(restoreBattle, 5).item == "FULL_RESTORE",
  "Full Restore is reserved for low HP")
assert(BattleState.aiUsesFor({ rematch = true, rematchAIUses = 16 }) == 16,
  "boss AI use budget survives enemy switches")
assert(BattleState.aiUsesFor({ rematch = true, rematchAIUses = 11 }) == 11,
  "field AI use budget survives enemy switches")
assert(BattleState.aiUsesFor({ rematch = false }) == 3,
  "normal trainer AI budget is unchanged")
assert(BattleState.trainerAIAction({ rematch = false }).special == "vanilla",
  "normal trainer AI action is unchanged")

-- The Oak gate is checked by the same menu-row builder used by BOSS REMATCH.
local six = {
  { species = "BULBASAUR", level = 78 }, { species = "CHARMANDER", level = 80 },
  { species = "SQUIRTLE", level = 82 }, { species = "ZAPDOS", level = 84 },
  { species = "ONIX", level = 86 }, { species = "KADABRA", level = 88 },
}
data.trainers = {
  OPP_LORELEI = { parties = { six } }, OPP_BRUNO = { parties = { six } },
  OPP_AGATHA = { parties = { six } }, OPP_LANCE = { parties = { six } },
  OPP_RIVAL3 = { parties = { six } }, OPP_PROF_OAK = { parties = { six } },
}
local finishCalls, gamePushed = 0, nil
local game = {
  data = data,
  save = { flags = { EVENT_BEAT_CHAMPION_RIVAL = true },
           player = { rivalStarter = 1 } },
  stack = {
    top = function()
      return { pushBattle = function(_, battle) gamePushed = battle end }
    end,
  },
}
local function hasOak(rows)
  for _, row in ipairs(rows) do if row.label == "PROF. OAK" then return true end end
  return false
end
local function rowFor(rows, label)
  for _, row in ipairs(rows) do if row.label == label then return row end end
end
local rowsBefore = ex.buildBossRows(game)
assert(not hasOak(rowsBefore), "Oak is hidden before the Rival rematch is won")
assert(rowFor(rowsBefore, "RIVAL").right == "#1", "Rival rematch count starts at one")
BattleState.newTrainer = function(g, classId, partyIndex)
  local party = g.data.trainers[classId].parties[partyIndex]
  local enemyParty = {}
  for i, _ in ipairs(party) do enemyParty[i] = { moves = {} } end
  return {
    enemyParty = enemyParty,
    enemy = { mon = enemyParty[1], curMoves = enemyParty[1].moves },
    onFinish = function() finishCalls = finishCalls + 1 end,
  }
end
local menu = { close = function() end }
local rivalEntry = { trainerClass = "OPP_RIVAL3", partyIndex = 1,
  aceCap = 200, unlockOakOnWin = true }
assert(ex.startBossRematch(game, rivalEntry, menu, BattleState),
  "Rival rematch can be started")
local rivalBattle = assert(gamePushed, "Rival battle was pushed")
assert(rivalBattle.enemy.curMoves == rivalBattle.enemy.mon.moves,
  "randomized active moves are attached to the active battler")
rivalBattle.onFinish("lose")
local rowsAfterLoss = ex.buildBossRows(game)
assert(not hasOak(rowsAfterLoss), "losing the Rival rematch does not unlock Oak")
assert(rowFor(rowsAfterLoss, "RIVAL").right == "#2",
  "boss rematch count persists after a completed attempt")
assert(ex.startBossRematch(game, rivalEntry, menu, BattleState),
  "Rival rematch can be repeated")
local winningRivalBattle = assert(gamePushed)
winningRivalBattle.onFinish("win")
assert(finishCalls == 2, "vanilla finish callbacks remain chained")
local rowsAfterWin = ex.buildBossRows(game)
assert(hasOak(rowsAfterWin), "winning the Rival rematch unlocks Oak")
assert(rowFor(rowsAfterWin, "RIVAL").right == "#3",
  "Rival rematch counter keeps increasing across repeat battles")
assert(rowFor(rowsAfterWin, "PROF. OAK").right == "#1",
  "Oak progression starts separately after unlock")

print("rematch standalone smoke checks passed")
